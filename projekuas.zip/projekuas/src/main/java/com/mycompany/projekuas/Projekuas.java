/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projekuas;

/**
 *
 * @author EKA
 */
public class Projekuas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
